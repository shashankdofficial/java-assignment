package question3;

public interface Interface {

	int x=10;
	int y=20;
	public abstract void example();
}
