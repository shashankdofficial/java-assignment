package question1;

public class RoadSideHotel implements Hotel{

	@Override
	public void chickenBiryani() {
		
	}

	@Override
	public void masalaDosa() {
		System.out.println("This Is RoadSideotel's Masala Dosa");
		
	}
}
