package question1;

public class TajHotel implements Hotel{

	@Override
	public void chickenBiryani() {
		
	}

	@Override
	public void masalaDosa() {
		
	}

	public void welcomeDrink(){
		System.out.println("Welcome Drink from the TajHotel");
		}
}
