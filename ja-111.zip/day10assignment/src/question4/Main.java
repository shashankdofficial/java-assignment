package question4;

public class Main {

	public static void main(String[] args) {
		Area area = new Area();
	    System.out.println("Area of Circle:"+area.circleArea(5));
		System.out.println("Area of Reatangle:"+area.rectangleArea(23, 16));
		System.out.println("Area of Square:"+area.squareArea(8));
	}
}
