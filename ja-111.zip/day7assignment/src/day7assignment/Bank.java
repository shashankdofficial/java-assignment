package day7assignment;

public class Bank {
	String branchName;
	String ifscCode;

	void displayDetails() {
		
	};
}
