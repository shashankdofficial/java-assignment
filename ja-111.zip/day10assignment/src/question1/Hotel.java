package question1;

public interface Hotel {

	void chickenBiryani();
	void masalaDosa();
}
