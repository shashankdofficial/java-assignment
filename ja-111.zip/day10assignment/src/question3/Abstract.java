package question3;

public abstract class Abstract {

	public abstract void print();
}
