package question1;

public interface Z extends X,Y{

	abstract void fun1();
}
