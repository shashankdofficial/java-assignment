package animalCatDog;

public class Tiger extends Animal{

	@Override
	public void makeNoise(){
		System.out.println("Roaring...");
	}
}
