package com.java11.q1;

public class ImplZ implements Z {

	@Override
	public void absForX() {
		System.out.println("Inside ImplZ");
		
	}

	@Override
	public void defaultForX() {
		System.out.println("Inside ImplZ");
		
	}

	@Override
	public void absForY() {
		System.out.println("Inside ImplZ");
		
	}


	@Override
	public void absForZ() {
		System.out.println("Inside ImplZ");
		
	}

	

}
