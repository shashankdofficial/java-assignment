package question3;

public class ChildAbstract extends Abstract{

	@Override
	public void print() {
		System.out.println("This is abstract class");
		
	}
}
