package classCastException;

public class A {

	//Open Main file to understand ClassCastException
	
	void funA() {
		System.out.println("Inside funA of A");
	}
}
