package animalCatDog;

public class Animal {

	public void makeNoise(){
		System.out.println("Animal making Noise");
	}
	public void eat(){
		System.out.println("Animal is eating");
	}
	public void walk(){
		System.out.println("Animal is walking");
	}
}
