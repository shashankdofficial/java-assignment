package whyMultiInheritance;

public class MultipleInheritance {

	//Let suppose we have 3 classes
	//Class A
	//Class B
	//And Class C
	//Now if
	//Class A extends Class B and Class C both
	//And if in both of the Classes have same methods then the Complite will confus that
	//Whom to get execute.
	//So this is the main reason why JAVA not Support Multiple Inheritance.

}
