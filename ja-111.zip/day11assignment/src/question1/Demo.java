package question1;

public class Demo extends ZImpl{

	public static void main(String[] args) {
		
		Demo d1 = new Demo();
		
		d1.funX();
		d1.funY();
		d1.funA();
		d1.funB();
		d1.fun1();
	}

}
