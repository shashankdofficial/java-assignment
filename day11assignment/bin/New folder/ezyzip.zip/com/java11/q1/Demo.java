package com.java11.q1;

public class Demo {
	public static void main(String[] args) {
		
		ImplZ z1=new ImplZ();
		z1.absForX();
		z1.absForY();
		z1.absForZ();
		
		z1.defaultForX();
		z1.defaultForY();
	}

}
