package com.java11.q1;

public interface Z extends X,Y {
	
	public abstract void absForZ();
}
