package question3;

public class ChildInterface implements Interface{

	@Override
	public void example() {
		System.out.println("This is the child of Interfacae");
		
	}
}
