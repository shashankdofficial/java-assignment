package classCastException;

public class B extends A{

	//Open Main file to understand ClassCastException
	
	void funB() {
		System.out.println("Inside funB of B");
	}
}
