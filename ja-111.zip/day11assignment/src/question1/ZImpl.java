package question1;

public class ZImpl implements Z{

	@Override
	public void funX() {
		System.out.println("inside funX of ZImpl");
	}

	@Override
	public void funA() {
		System.out.println("inside funA of ZImpl");
	}

	@Override
	public void fun1() {
		System.out.println("inside fun1 of ZImpl");
	}
	
}
